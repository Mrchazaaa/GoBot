========================NOTES========================================

Eventually, I plan to publish the source code for this project, after a few minor improvements and code cleaning.


====================INSTALLATION=====================================

1. Unpack this zip file in your directory of choice

2. Run the .exe executable if using Windows ( or the .x64 for linux )

